package com.example.seagull;

public interface FormSubmitListener {
    void onFormSubmit(LineItem lineItem, boolean isExpense);
}
