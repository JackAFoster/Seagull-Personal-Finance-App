package com.example.seagull;

public class Goals {


}
