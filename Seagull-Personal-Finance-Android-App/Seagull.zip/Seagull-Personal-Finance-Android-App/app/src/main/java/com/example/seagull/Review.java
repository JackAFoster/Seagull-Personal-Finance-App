package com.example.seagull;

public class Review {
}
