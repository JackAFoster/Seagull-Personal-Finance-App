package com.example.seagull;

public class Map {
}
